# 0721模式 AstrBot 插件

读取本地状态并注入到 AstrBot LLM 请求中，也提供 `/vibe` 命令和本地 WebUI 控制面板。

## 主要功能

- `/vibe on/off/status/lock/unlock/set/force/deny/undeny/safeword`
- 身体日记与成就：`/vibe diary`、`/vibe achievements`
- 本地 WebUI 控制面板：默认 `http://localhost:7721`
- LLM 状态注入和 LLM Tools 控制
- 主动私聊消息推送

## 指定用户使用

在插件配置中填写 `allowed_sids` 可以限制可使用用户。

- 留空：不限制，保持默认行为
- 推荐直接填写数字 QQ 号/UID，例如 `123456789`
- 也支持完整 UMO，例如 `BotID:FriendMessage:123456789`
- 多个 UID/UMO：用逗号或换行分隔
- 生效范围：`/vibe` 命令、LLM Tools、LLM 注入、主动消息 session 记录
- WebUI 没有 AstrBot event，仍使用 `webui_password` 控制访问

如果不知道自己的 UID，可以临时不填白名单，在 AstrBot 会话信息里查看 `UID`；插件也会兼容完整 `UMO`，格式通常类似 `BotID:FriendMessage:UID`。

## 主动消息目标

WebUI 没有 AstrBot event 上下文，无法自动知道应该把主动消息发到哪个私聊。需要 WebUI 开启后也主动推送时，在插件配置里填写 `auto_message_session`。

- 推荐格式：完整 UMO，例如 `BotID:FriendMessage:123456789`
- 如果 `auto_message_session` 留空，插件会尝试从 `allowed_sids` 中取第一个完整 UMO
- 只填数字 QQ 号/UID 可以用于白名单，但不能单独作为主动推送路由
- 私聊里使用 `/vibe on` 或 `/vibe automsg on` 时，会自动记录当前私聊为主动消息目标

可用 `/vibe automsg status` 查看当前目标会话和下次最早发送时间，用 `/vibe automsg test` 测试发送链路。

## 安全建议

- `webui_password` 不要留空，尤其是 WebUI 绑定到局域网地址时。
- 默认单状态自用；如果多人同时使用，建议配置 `allowed_sids`。
- 状态文件 `vibe_state.json` 是运行态文件，不应提交或打包进仓库。
